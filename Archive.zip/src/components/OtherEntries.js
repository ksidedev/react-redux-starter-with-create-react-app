import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Button, DropdownButton, MenuItem } from 'react-bootstrap';
// import { getOtherFakeData } from '../shared/helpers'
import { AircraftData } from '../shared/actions'
import Accordion from './Accordion/Accordion'
import './Styles/OtherEntries/OtherEntries.css'

class OtherEntries extends Component {
  render() {
    return (
      <div className="formWrapper row">
        <Accordion />
      </div>
    )
  }
}

export default OtherEntries