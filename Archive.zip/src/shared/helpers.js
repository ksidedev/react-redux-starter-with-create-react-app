/* eslint no-console: ["error", { allow: ["error"] }] */
import fetch from 'unfetch'
import { AircraftData } from './actions'

import { endpoints } from '../constants'
/* eslint-disable no-unused-vars */
let otherEndPointUrl = ''
let sharedPlanOptionsUrl = ''
/* eslint-enable no-unused-vars */


export function GetCreateAircraftData(dispatch, payload) {
  return fetch(endpoints.postedDataEndpoint, {
    method: 'post',
    headers: {
      'Accept': 'application/json, text/plain, */*',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        email: payload.email,
        password: payload.password
    })
  })
    .then(r => r.json())
    .then(data => {
      if (data) {
        dispatch(AircraftData(data))
        return Promise.resolve()
      }

      return Promise.reject()
    })
    .catch(error => {
      console.error(error)
      return null
    })
}
