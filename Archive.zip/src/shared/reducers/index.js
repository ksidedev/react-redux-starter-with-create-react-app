export const initialState = {
  AircraftData: {},
  theReturnedPostData: {},
  SelectedSendPoint: "Select Point Type"
}

export default (state = initialState, action) => {
  switch (action.type) {
    case 'AIRCRAFT_DATA':
      return Object.assign({}, state, {
        AircraftData: action.aircraft
      })
    case 'SELECTED_SEND_POINT':
      return Object.assign({}, state, {
        SelectedSendPoint: action.send
      })
    default:
      return state
  }
}
