import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Button, DropdownButton, MenuItem } from 'react-bootstrap';
// import { getOtherFakeData } from '../shared/helpers'
import './Styles/CreateTrack/CreateTrack.css'

class CreateTrack extends Component {
  constructor(props: any) {
    super(props)
  }

  render() {
    return (
      <div className="formWrapper row">
       
      </div>
    )
  }
}

export default connect(state => ({
  AircraftData: state.AircraftData
}))(CreateTrack)
