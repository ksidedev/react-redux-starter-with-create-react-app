export const AircraftData = aircraft => ({
  type: 'AIRCRAFT_DATA',
  aircraft
})

export const SelectedSendPoint = send => ({
  type: 'SELECTED_SEND_POINT',
  send
})
