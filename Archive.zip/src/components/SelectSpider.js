import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Button, DropdownButton, MenuItem } from 'react-bootstrap';
// import { getOtherFakeData } from '../shared/helpers'
import { AircraftData } from '../shared/actions'
import './Styles/CreateAircraft/CreateAircraft.css'

class SelectSpider extends Component {
  constructor(props: any) {
    super(props)

    // this.state = {
    //   aircraftCreation: {name: '', serianlNum: ''},
    // }
    this.getAircraftName = this.getAircraftName.bind(this)
  }

  getAircraftName(event) {
    // aircraftCreation: {name: event.target.value, serianlNum: ''}
    this.props.dispatch(AircraftData({name: event.target.value, serianlNum: ''}))
  }

  render() {
    return (
      <div className="formWrapper row">
        <br />
        <div className="form-post col-xs-12">
            <div className="inputWrapper">
              <h4 className="col-xs-12">Select Spider</h4>
              <div className="col-xs-6">
                <p>Option 1</p>
                <input
                  onKeyUp={this.getAircraftName}
                  name="name"
                  onChange={this.onChange}
                />
              </div>

              <div className="col-xs-6">
                <p>Option 2</p>
                <DropdownButton
                  title={'Select Point Type'}
                  id="selectSpider"
                >
                  <MenuItem eventKey="1">Action</MenuItem>
                  <MenuItem eventKey="2">Another action</MenuItem>
                  <MenuItem eventKey="3" active>
                    Active Item
                  </MenuItem>
                  <MenuItem divider />
                  <MenuItem eventKey="4">Separated link</MenuItem>
                </DropdownButton>
              </div>
            </div>
          </div>  
        </div>
    )
  }
}

export default connect(state => ({
  AircraftData: state.AircraftData
}))(SelectSpider)
