import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Button, DropdownButton, MenuItem } from 'react-bootstrap';
// import { getOtherFakeData } from '../shared/helpers'
import { AircraftData, SelectedSendPoint } from '../shared/actions'
import './Styles/SendPoint/SendPoint.css'

class SendPoint extends Component {
  constructor(props: any) {
    super(props)
    this.getSendPointOption = this.getSendPointOption.bind(this)
  }

  getSendPointOption(event) {
    this.props.dispatch(SelectedSendPoint(event.target.getAttribute('eventkey')))
  }

  render() {
    let option
    if(this.props.SelectedSendPoint === 'spidertext') {
      option = 'Spidertxt'
    }else if (this.props.SelectedSendPoint === 'speed') {
      option = 'speed'
    }
    else if (this.props.SelectedSendPoint === 'rateclimb') {
      option = 'Rate Climb'
    }
    else if (this.props.SelectedSendPoint === 'ratedecent') {
      option = 'Rate Decent'
    }
    else {
      option = 'Select Point Type'
    }
    return (
      <div className="formWrapper row sendPoint">
        <hr />
        <div className="form-post col-xs-12">
            <div className="inputWrapper">
              <div className="col-xs-10">
                <h4>Send Point</h4>
                <div className="col-xs-12 no-padding pointType">
                  <DropdownButton
                    title={option}
                    id="Spidertxt"
                  >
                    <MenuItem eventkey={'spidertext'} onClick={this.getSendPointOption} eventKey="1">Spidertxt</MenuItem>
                    <MenuItem eventkey={'speed'} onClick={this.getSendPointOption} eventKey="2">SpeedUp / speedDown</MenuItem>
                    <MenuItem eventkey={'rateclimb'} onClick={this.getSendPointOption} eventKey="3">rateClimbOn / rateClimbOff</MenuItem>
                    <MenuItem eventkey={'ratedecent'} onClick={this.getSendPointOption} eventKey="4">rateDecentOn / rateDecentOff</MenuItem>
                  </DropdownButton>

                  <div className="col-xs-3 send no-padding">
                    <button>Send</button>
                  </div>
                </div>
              </div>
            </div>  
        </div>
      </div>
    )
  }
}

export default connect(state => ({
  AircraftData: state.AircraftData,
  SelectedSendPoint: state.SelectedSendPoint
}))(SendPoint)
