# React-Redux-Basic-Starter
Basic react examples with Redux, Redux logger, SASS & Prettier.

It uses `create-react-app`

## Using NPM

#### Run the app

```
npm install

npm start
```

#### Format Code
```
npm run format
```

#### Build for deployment
```
npm run build
```
__

## Using Yarn

```
yarn install

yarn start
```
#### Build for deployment
```
yarn run build
```

open http://localhost:3000/
